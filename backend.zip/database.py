# backend/database.py
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# AWS RDS PostgreSQL database URL
DATABASE_URL = "postgresql+psycopg2://postgres:bilal12345@database-2.cufyiuo2iwj7.us-east-1.rds.amazonaws.com:5432/postgres"

# SQLAlchemy engine
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,  # keeps idle connections alive, useful for EB
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()

# Dependency for FastAPI routes
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()